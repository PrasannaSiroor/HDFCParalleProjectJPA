package com.cg.mypaymentapp.exception;

public class InvalidInputException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4173217419927765766L;

	public InvalidInputException(String msg) {
		super(msg);
	}
}
